﻿using Microsoft.EntityFrameworkCore;
using ToDoApp.Api.Models;

namespace ToDoApp.Api.Data
{
    public class ToDoDbContext : DbContext
    {
        public ToDoDbContext(DbContextOptions<ToDoDbContext> options) : base(options)
        {
        }

       
        public DbSet<TodoTask> Tasks{ get; set; } 
        public DbSet<User> Users { get; set; }
        public DbSet<Role> roles { get; set; }
        public DbSet<TodoStatus> TaskStatuses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TodoTask>().ToTable("Task");
            modelBuilder.Entity<TodoStatus>().ToTable("TaskStatus");
            modelBuilder.Entity<Models.TodoStatus>()
                .Property(p => p.StatusName) 
                .HasColumnName("TaskStatus"); 
        }
    }
}