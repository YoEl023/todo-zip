﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToDoApp.Api.Data;
using ToDoApp.Api.Models;

[Authorize]
[Route("api/[controller]")]
[ApiController]
public class TasksController : ControllerBase
{
    private readonly ToDoDbContext _context;

    public TasksController(ToDoDbContext context)
    {
        _context = context;
    }

    private int GetCurrentUserId()
    {
        var userIdString = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return int.Parse(userIdString!);
    }


 
    [HttpPost]
    public async Task<ActionResult<TodoTask>> CreateTask(TodoTask task)
    {
        int userId = GetCurrentUserId();

        bool taskExists = await _context.Tasks
           .AnyAsync(t => t.UserID == userId && t.TaskName.ToLower() == task.TaskName.ToLower() && t.IsDeleted == false);

        if (taskExists)
        {
            return BadRequest("A task with this name already exists.");
        }

        task.UserID = userId;
        task.StatusID = 1;
        task.IsDeleted = false;

        
        _context.Tasks.Add(task);
        await _context.SaveChangesAsync();
        return StatusCode(201, task);
    }


   
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateTask(int id, TodoTask updatedTask)
    {
        if (id != updatedTask.TaskID)
        {
            return BadRequest("ID in URL does not match ID in the body.");
        }

        int currentUserId = GetCurrentUserId();

        var taskToUpdate = await _context.Tasks.FindAsync(id);

        if (taskToUpdate == null)
        {
            return NotFound("The task you are trying to update does not exist.");
        }

        if (taskToUpdate.UserID != currentUserId && !User.IsInRole("Admin"))
        {
            // 403 Forbidden 
            return Forbid();
        }

        bool taskExists = await _context.Tasks
    .AnyAsync(t => t.UserID == currentUserId &&
                   t.TaskName.ToLower() == updatedTask.TaskName.ToLower() &&
                   t.TaskID != id && 
                   t.IsDeleted == false);

        if (taskExists)
        {
            return BadRequest("Another task with this name already exists.");
        }


        taskToUpdate.TaskName = updatedTask.TaskName;

        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTask(int id)
    {
        int currentUserId = GetCurrentUserId();

        var taskToDelete = await _context.Tasks.FindAsync(id);

        if (taskToDelete == null)
        {
            return NotFound();
        }

        if (taskToDelete.UserID != currentUserId && !User.IsInRole("Admin"))

        {
            return Forbid();
        }
        
        taskToDelete.IsDeleted = true;
        await _context.SaveChangesAsync();

        return NoContent();
    }

  

    
    [HttpPost("{id}/complete")]
    public async Task<IActionResult> MarkTaskAsComplete(int id)
    {
        int currentUserId = GetCurrentUserId();
        var task = await _context.Tasks.FindAsync(id);

        if (task == null)
        {
            return NotFound();
        }

        if (task.UserID != currentUserId && !User.IsInRole("Admin"))
        {
            return Forbid();
        }

        
        task.StatusID = 2;

        await _context.SaveChangesAsync();
        return NoContent();
    }

   
    [HttpPost("{id}/revert")]
    public async Task<IActionResult> RevertTaskToDo(int id)
    {
        int currentUserId = GetCurrentUserId();
        var task = await _context.Tasks.FindAsync(id);

        if (task == null)
        {
            return NotFound();
        }

        if (task.UserID != currentUserId && !User.IsInRole("Admin"))
        {
            return Forbid();
        }

        
        task.StatusID = 1;

        await _context.SaveChangesAsync();
        return NoContent();
    }


    [HttpGet("deleted")]
    [Authorize(Roles = "Admin")] 
    public async Task<ActionResult<IEnumerable<TodoTask>>> GetDeletedTasks()
    {
            var deletedTasks = await _context.Tasks
            .Where(t => t.IsDeleted == true)
            .ToListAsync();

        return Ok(deletedTasks);
    }


    [HttpPost("{id}/restore")]
    [Authorize(Roles = "Admin")] 
    public async Task<IActionResult> RestoreTask(int id)
    {
        var taskToRestore = await _context.Tasks.FindAsync(id);

        if (taskToRestore == null)
        {
            return NotFound("Task not found.");
        }
        
        if (taskToRestore.IsDeleted == false)
        {
            return BadRequest("This task is not currently deleted.");
        }

        taskToRestore.IsDeleted = false;

        await _context.SaveChangesAsync();

        return NoContent();
    }


    [HttpGet]
    public async Task<ActionResult<IEnumerable<TodoTask>>> GetTasks([FromQuery] string? search = null)
    {
        var query = _context.Tasks.Where(t => t.IsDeleted == false);

        if (!User.IsInRole("Admin"))
        {
            int userId = GetCurrentUserId();
            query = query.Where(t => t.UserID == userId);
        }

        if (!string.IsNullOrEmpty(search))
        {
            query = query.Where(t => EF.Functions.Like(t.TaskName, $"%{search}%"));
        }

        var tasks = await query.ToListAsync();
        return Ok(tasks);
    }

}