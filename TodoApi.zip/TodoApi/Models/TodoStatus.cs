﻿using System.ComponentModel.DataAnnotations;

namespace ToDoApp.Api.Models
{
    public class TodoStatus
    {
        [Key]
        public int StatusID { get; set; }

        public string StatusName { get; set; } = string.Empty;
    }
}