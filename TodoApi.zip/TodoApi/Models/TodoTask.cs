﻿using System.ComponentModel.DataAnnotations;

namespace ToDoApp.Api.Models
{
    public class TodoTask
    {
        [Key]
        public int TaskID { get; set; }

        [Required(ErrorMessage = "Task name cannot be empty.")]
        public string TaskName { get; set; } =  string.Empty;

        public bool IsDeleted { get; set; }

        public int UserID { get; set; }

        public int StatusID { get; set; }

        public User?User { get; set; }

        public TodoStatus?Status { get; set; }
    }
}