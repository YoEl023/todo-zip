﻿using System.ComponentModel.DataAnnotations;

namespace ToDoApp.Api.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }

        public string UserName { get; set; } = string.Empty;

        public string passwordHash { get; set; } = string.Empty;
        

        public int RoleID { get; set; }

        public Role?Role { get; set; }
    }
}