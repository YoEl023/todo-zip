import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Auth } from './auth'; 
import { Task } from '../models/task.model'; 

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private apiUrl = `${environment.apiUrl}/tasks`; 

  constructor(
    private http: HttpClient,
    private authService: Auth
  ) { }

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  getTasks(): Observable<Task[]> { 
    return this.http.get<Task[]>(this.apiUrl, { headers: this.getAuthHeaders() });
  }

  createTask(taskData: { taskName: string }): Observable<Task> {
    return this.http.post<Task>(this.apiUrl, taskData, { headers: this.getAuthHeaders() });
  }

  updateTask(taskId: number, taskData: Task): Observable<any> {
    const url = `${this.apiUrl}/${taskId}`;
    return this.http.put(url, taskData, { headers: this.getAuthHeaders() });
  }

  deleteTask(taskId: number): Observable<any> {
    const url = `${this.apiUrl}/${taskId}`;
    return this.http.delete(url, { headers: this.getAuthHeaders() });
  }

  markTaskAsComplete(taskId: number): Observable<any> {
    const url = `${this.apiUrl}/${taskId}/complete`;
    return this.http.post(url, {}, { headers: this.getAuthHeaders() }); // No body needed, so we send an empty object {}
  }

  revertTaskToDo(taskId: number): Observable<any> {
    const url = `${this.apiUrl}/${taskId}/revert`;
    return this.http.post(url, {}, { headers: this.getAuthHeaders() });
  }

  getDeletedTasks(): Observable<Task[]> {
    const url = `${this.apiUrl}/deleted`;
    return this.http.get<Task[]>(url, { headers: this.getAuthHeaders() });
  }

  restoreTask(taskId: number): Observable<any> {
    const url = `${this.apiUrl}/${taskId}/restore`;
    return this.http.post(url, {}, { headers: this.getAuthHeaders() });
  }
}