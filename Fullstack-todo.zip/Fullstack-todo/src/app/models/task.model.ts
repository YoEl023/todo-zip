
export interface Task {
    taskID: number;
    taskName: string;
    isDeleted: boolean;
    userID: number;
    statusID: number;
}