import { Component, Input, Output, EventEmitter } from '@angular/core'; // 1. Import Output and EventEmitter
import { CommonModule } from '@angular/common';
import { Task } from '../../models/task.model';

import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-task-table',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatButtonModule, MatIconModule],
  templateUrl: './task-table.html',
  styleUrl: './task-table.css'
})
export class TaskTable {
  @Input() dataSource: Task[] = [];
  
  @Output() deleteTask = new EventEmitter<Task>();
  @Output() completeTask = new EventEmitter<Task>();
  @Output() revertTask = new EventEmitter<Task>();
  @Output() editTask = new EventEmitter<Task>();
  
  displayedColumns: string[] = ['sno', 'taskName', 'status', 'actions'];

  constructor() {}

  onDelete(task: Task): void {
    this.deleteTask.emit(task);
  }

  onToggleStatus(task: Task): void {
    if (task.statusID === 1) {
      this.completeTask.emit(task);
    } else {
      this.revertTask.emit(task);
    }
  }

  onEdit(task: Task): void {
    this.editTask.emit(task);
  }
}