import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Task } from '../../models/task.model';
import { TaskService } from '../../services/task';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TaskTable } from '../task-table/task-table'; // Import the child component

// Import all the Material modules we'll need
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    TaskTable 
  ],
  templateUrl: './task-list.html',
  styleUrl: './task-list.css'
})
export class TaskList implements OnInit {
  
  todoTasks: Task[] = [];
  completedTasks: Task[] = [];
  
  displayedColumns: string[] = ['sno', 'taskName', 'status', 'actions'];
  newTaskForm!: FormGroup;

  constructor(
    private taskService: TaskService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadTasks();

    this.newTaskForm = this.fb.group({
      taskName: ['', Validators.required]
    });
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (data) => {
        this.todoTasks = data.filter(task => task.statusID === 1);
        this.completedTasks = data.filter(task => task.statusID === 2);
      },
      error: (err) => console.error('Failed to load tasks:', err)
    });
  }

  onAddTask(): void {
    if (this.newTaskForm.invalid) {
      return;
    }

    this.taskService.createTask(this.newTaskForm.value).subscribe({
      next: () => {
        console.log('Task added successfully!');
        this.loadTasks();
        this.newTaskForm.reset();
      },
      error: (err) => console.error('Failed to add task:', err)
    });
  }

  
  handleDelete(task: Task): void {
    if (confirm(`Are you sure you want to delete "${task.taskName}"?`)) {
      this.taskService.deleteTask(task.taskID).subscribe({
        next: () => {
          console.log('Task deleted successfully');
          this.loadTasks(); 
        },
        error: (err) => console.error('Failed to delete task:', err)
      });
    }
  }

  handleComplete(task: Task): void {
    this.taskService.markTaskAsComplete(task.taskID).subscribe({
      next: () => {
        console.log('Task marked as complete');
        this.loadTasks(); 
      },
      error: (err) => console.error('Failed to complete task:', err)
    });
  }

  handleRevert(task: Task): void {
    this.taskService.revertTaskToDo(task.taskID).subscribe({
      next: () => {
        console.log('Task reverted to to-do');
        this.loadTasks(); 
      error: (err) => console.error('Failed to revert task:', err)
    });
  }

  handleEdit(task: Task): void {
    console.log('Edit clicked for:', task);
  }
}