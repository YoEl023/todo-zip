import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Task } from '../../models/task.model';
import { TaskService } from '../../services/task';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs'; 

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule 
  templateUrl: './task-list.html',
  styleUrl: './task-list.css'
})
export class TaskList implements OnInit {
  todoTasks: Task[] = [];
  completedTasks: Task[] = [];
  
  displayedColumns: string[] = ['sno', 'taskName', 'status', 'actions'];
  newTaskForm!: FormGroup;

  constructor(
    private taskService: TaskService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.loadTasks();
    this.newTaskForm = this.fb.group({
      taskName: ['', Validators.required]
    });
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (data) => {
        this.todoTasks = data.filter(task => task.statusID === 1);
        this.completedTasks = data.filter(task => task.statusID === 2);
      },
      error: (err) => console.error('Failed to load tasks:', err)
    });
  }

  onAddTask(): void {
    if (this.newTaskForm.invalid) return;

    this.taskService.createTask(this.newTaskForm.value).subscribe({
      next: () => {
        this.loadTasks(); 
        this.newTaskForm.reset();
      },
      error: (err) => console.error('Failed to add task:', err)
    });
  }
}